<div>
    <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top text-center" >
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" style="background-color: black" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <!--<img src="../img/logos/icofestival.png" alt="" height="70%" width="60%">-->
        </a>

        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav "><!--ml-auto-->
            <!-- <li class="nav-item active">
                <a class="nav-link" href="#">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>-->
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/')); ?>">INICIO</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/peliculas')); ?>">PELÍCULAS</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="proyectos.php">WAWAS AL CINE</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="galeria.php">PROGRAMACIÓN</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">NOTICIAS</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">GALERIA</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">NOSOTROS</a>
                </li>

            </ul>

        </div>
        <div class="flex-center position-ref float-right ">
                <?php if(Route::has('login')): ?>
                    <div class="right link buttonunion" style="padding: 0 0 px">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->rol == 'admin'): ?>
                                   <a href="<?php echo e(url('/admin')); ?>">  PERFIL ADMIN</a>
                            <?php endif; ?>

                             <?php if(Auth::user()->rol == 'user'): ?>
                                   <a href="<?php echo e(url('/home')); ?>">  PERFIL</a>
                            <?php endif; ?>


                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"><button type="button" class="btn btn-outline-dark">INGRESA</button></a>

                            <?php if(Route::has('register')): ?>

                                <a href="<?php echo e(route('register')); ?>"><button type="button" class="btn btn-warning">REGISTRATE</button></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>
    </div>
</nav>
</div>
<?php /**PATH C:\xampp\htdocs\kuntur\resources\views/components/navBar2.blade.php ENDPATH**/ ?>