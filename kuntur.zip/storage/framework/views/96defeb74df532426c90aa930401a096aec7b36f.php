

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" >
        <?php echo $__env->make('components/sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-12 col-sm-12 col-md-10 col-lg-9 col-xl-9">
                <h1>Listado de Películas</h1>
                <hr>
               
                <div class="alert alert-success" role="alert">
                    <?php if(Session::has('Mensaje')): ?><?php echo e(Session::get('Mensaje')); ?><?php endif; ?>
                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Imagen</th>
                            <th>Titulo</th>
                            <th>Director</th>
                            <th>Categoria</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>                
                                <img src="<?php echo e(asset('storage').'/'. $film->film_imagen); ?>" alt="foto" width="70px" height="110px">  <!--se debe agregar php artisan storage:link-->                  
                            </td>
                            <td><?php echo e($film->film_Titulo); ?></td>
                            <td><?php echo e($film->film_Director); ?></td>
                            <td><?php echo e($film->film_Categoria); ?></td>
                            <td><?php echo e($film->film_Estado); ?></td>
                            
                            
                            <td>

                            <a href="<?php echo e(url('/edit/'.$film->id.'/edit')); ?>">
                                <button type="button" class="btn btn-warning"> Editar</button>
                            </a>

                            <form method="post" action="<?php echo e(url('/delete/'.$film->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="Submit" class="btn btn-danger" onclick="return confirm('¿Desea Borrar?');  " > Borrar</button>
                            </form>         
                           
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                 
            </div>
    
    </div>
</div>





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuntur\resources\views/admin/listFilm.blade.php ENDPATH**/ ?>