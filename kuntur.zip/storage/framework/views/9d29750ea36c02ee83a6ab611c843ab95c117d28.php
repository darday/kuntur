

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" >
        <?php echo $__env->make('components/sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-12 col-sm-12 col-md-10 col-lg-9 col-xl-9">
                <hr>
                <h1>BIENVENIDO AL SISTEMA DEL FESTIVAL KUNTURÑAWI IX</h1>
                <hr>
                 
            </div>
    
    </div>
</div>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuntur\resources\views/admin/admin.blade.php ENDPATH**/ ?>