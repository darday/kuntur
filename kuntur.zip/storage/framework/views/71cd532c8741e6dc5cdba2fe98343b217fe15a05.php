<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('components/navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="breadcumb-area ">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="bradcumb-title text-center animated zoomIn"><br><br><br>
                        <h2>RESEÑA HISTÓRICA</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--------------------------------Informacion-------------------------------->
<br>
<br>
<br>
<br>
<div class="container animated fadeIn">
    <div class="row ">
      <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 text-center">
          <img src="assets/images/logos_fundacion-01.png" alt="imagen" height="80%" class="responsive">
      </div>
      
    
   
    
  </div>
<!--------------------------------Informacion-------------------------------->

<!--------------------------------Footer-------------------------------------->
<!-- Footer -->
<br>
<br>
<br>
<br>




<!-- Footer -->
<!--------------------------------Footer-------------------------------------->


    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuntur\resources\views/nosotros.blade.php ENDPATH**/ ?>