<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <?php echo $__env->make('components/sideBarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="text-transform: uppercase;">BIENVENIDO <?php echo e(Auth::user()->name); ?> AL FESTIVAL DE CINE KUNTURÑAWI</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Ahora tu puedes dar tu voto en cada uno de los Films y ayudar a escoger el ganador.
                </div>
            </div>
        </div>
    </div>
</div>







<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuntur\resources\views/home.blade.php ENDPATH**/ ?>