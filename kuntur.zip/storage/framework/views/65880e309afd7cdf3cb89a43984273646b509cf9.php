

  <div class="col-12 col-sm-12 col-md-2 col-lg-3 col-xl-3">
    <div class="list-group">
        <a href="<?php echo e(url('/home')); ?>" class="list-group-item list-group-item-action active">
            Home
        </a>
        <a href="<?php echo e(url('/lista')); ?>" class="list-group-item list-group-item-action">Ver mis Votos</a>
        <a href="#" class="list-group-item list-group-item-action">Editar Información</a>
        
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\kuntur\resources\views/components/sideBarUser.blade.php ENDPATH**/ ?>