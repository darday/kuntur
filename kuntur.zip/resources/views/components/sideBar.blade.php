

  <div class="col-12 col-sm-12 col-md-2 col-lg-3 col-xl-3">
    <div class="list-group">
        <a href="{{ url('/admin') }}" class="list-group-item list-group-item-action active">
            Home
        </a>
        <a href="{{ url('/create') }}" class="list-group-item list-group-item-action">Agregar Pelicula</a>
        <a href="{{ url('/listar') }}" class="list-group-item list-group-item-action">Listar Pelicula</a>
        <a href="#" class="list-group-item list-group-item-action">Agregar Noticias</a>
        <a href="#" class="list-group-item list-group-item-action">Listar Noticias</a>
        <a href="#" class="list-group-item list-group-item-action">Agregar Fotos</a>
        <a href="#" class="list-group-item list-group-item-action">Listar Fotos</a>
        <a href="#" class="list-group-item list-group-item-action">Listar Usuarios</a>
        <a href="#" class="list-group-item list-group-item-action">Estadisticas</a>
        <a href="#" class="list-group-item list-group-item-action">Comentarios</a>
    </div>
  </div>
