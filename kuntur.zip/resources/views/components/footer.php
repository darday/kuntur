<!--<footer class="page-footer font-small special-color-dark bg-dark pt-4">

  <!-- Footer Elements -
  <div class="col-md-4 mx-auto ">
    <p style="color:white">Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
    consectetur
    adipisicing elit.</p>

    </div>

    <!-- Social buttons --
    <ul class="list-unstyled list-inline text-center">
      <li class="list-inline-item">        
        <a href="https://www.facebook.com/fundaciondeartenativo">
          <i class="fa fa-facebook-square" style="font-size:30px;color:white"></i>
        </a>
      </li>
      <li class="list-inline-item">
        <a href="https://twitter.com/piazurita">
          <i class="fa fa-twitter-square" style="font-size:30px;color:white"></i>
        </a>
      </li>
      <li class="list-inline-item">
        <a href="https://www.instagram.com/artenativofundacion/?hl=es-la">
          <i class="fa fa-instagram" style="font-size:30px;color:white"></i>
        </a>
      </li>
      <li class="list-inline-item">
        <a href="https://www.youtube.com/channel/UCArq9__EFYHusjL-ZYiAKiA/featured">
          <i class="fa fa-youtube-play" style="font-size:30px;color:white"></i>

        </a>
      </li>
      
     
    </ul>
    <!-- Social buttons --

  
  <!-- Footer Elements --

  <!-- Copyright --
  <div class="footer-copyright text-center py-3" style="color:white">©
    <a > Diseño Web: Darío Janeta</a>
  </div>
  <!-- Copyright --

</footer>-->

<!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4 bg-dark">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left ">

      <!-- Grid column 
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Company name</h6>
        <p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
          consectetur
          adipisicing elit.</p>
      </div>-->
      
      <div class="col-md-12 col-lg-12 col-xl-12 col-xl-12 " style="color:white">
        <h6 class="text-uppercase mb-4 font-weight-bold" >Contacto</h6>        
      </div>
      
        <div class=" col-md-6 col-lg-6  col-xl-6 " style="color:white">       
            <i class="fa fa-map-marker" style="color:white"></i>   Juan de Velasco 2060 y Guayaquil / Riobamba - Ecuador<br>        
            <i class="fa fa-envelope"  style="color:white"></i> festivalcinekunturnawi@gmail.com <br>       
        </div>
        <div class=" col-md-4 col-lg-6 col-xl-6 col-xl-6 " style="color:white">
                    
            <i class="fa fa-phone"  style="color:white"></i> (03) 2943168 <br>       
            <i class="fa fa-phone"  style="color:white"></i> 0992774388 – 0939212520
        </div>

      <!-- Grid column -->

    </div>
    <!-- Footer links -->

    <hr>

    <!-- Grid row -->
    <div class="row d-flex align-items-center" style="color:white">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left" style="color:white">©
             <a > Diseño Web: Darío Janeta</a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
                <a href="https://www.facebook.com/fundaciondeartenativo">
                    <i class="fa fa-facebook-square" style="font-size:30px;color:white"></i>
                </a>
            </li>
            <li class="list-inline-item">
                <a href="https://twitter.com/piazurita">
                    <i class="fa fa-twitter-square" style="font-size:30px;color:white"></i>
                </a>
            </li>
            <li class="list-inline-item">
                <a href="https://www.instagram.com/artenativofundacion/?hl=es-la">
                    <i class="fa fa-instagram" style="font-size:30px;color:white"></i>
                </a>
            </li>
            <li class="list-inline-item">
                <a href="https://www.youtube.com/channel/UCArq9__EFYHusjL-ZYiAKiA/featured">
                    <i class="fa fa-youtube-play" style="font-size:30px;color:white"></i>
                </a>
            </li>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->